package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Magnifier;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CONTACTS_ASK_PERMISSIONS = 1001;
    EditText search;
    ListView listView;
    ArrayList<String> data;
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        data = new ArrayList<>();
        if(checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[] {Manifest.permission.READ_CONTACTS}, REQUEST_CONTACTS_ASK_PERMISSIONS);

        }
        listView = findViewById(R.id.listView);
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        Cursor cursor = getContentResolver().query(uri, null, null, null);

        data.clear();
        while (cursor.moveToNext()){
            String columnName = ContactsContract.Contacts.DISPLAY_NAME;
            int posision = cursor.getColumnIndex(columnName);
            String name = cursor.getString(posision);
            data.add(name);
            System.out.println(name);

        }
        adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, data);
        listView.setAdapter(adapter);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String selection = ContactsContract.Contacts.DISPLAY_NAME + "like ?";

                String[] queryArgs = new String[] {"%"+s+"%"};
                Cursor cursor = getContentResolver().query(uri, null, selection, queryArgs, null);

                data.clear();
                while (cursor.moveToNext()){
                    String columnName = ContactsContract.Contacts.DISPLAY_NAME;
                    int posision = cursor.getColumnIndex(columnName);
                    String name = cursor.getString(posision);
                    data.add(name);
                    System.out.println(name);

                }

                adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, data);
                listView.deferNotifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {


            }
        });
    }
}